"""Version information for brainfart."""

__version__ = "0.1.0"
__version_tuple__ = (0, 1, 0)
